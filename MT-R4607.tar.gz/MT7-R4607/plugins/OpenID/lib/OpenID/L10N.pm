# Movable Type (r) (C) 2007-2019 Six Apart Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id$

package OpenID::L10N;

use strict;
use warnings;
use base 'MT::Plugin::L10N';

1;
