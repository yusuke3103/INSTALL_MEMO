# WidgetManager plugin for Movable Type
# Author: Byrne Reese, Six Apart (http://www.sixapart.com)
# Released under the Artistic License
#
# $Id$

package WidgetManager::L10N;
use strict;
use warnings;
use base 'MT::Plugin::L10N';

1;
