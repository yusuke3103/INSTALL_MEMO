# Movable Type (r) (C) 2005-2019 Six Apart Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id$

package TinyMCE::L10N::en_us;

use strict;
use warnings;

use base 'TinyMCE::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;
