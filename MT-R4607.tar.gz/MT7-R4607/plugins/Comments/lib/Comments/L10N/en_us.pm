package Comments::L10N::en_us;

use strict;
use warnings;
use utf8;
use base 'Comments::L10N';

our %Lexicon = (

);

1;
