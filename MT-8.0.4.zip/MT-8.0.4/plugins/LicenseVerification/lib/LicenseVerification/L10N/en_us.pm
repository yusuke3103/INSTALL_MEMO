# Movable Type (r) (C) Six Apart Ltd. All Rights Reserved.
# This code cannot be redistributed without permission from www.sixapart.com.
# For more information, consult your Movable Type license.
#
# $Id$

package LicenseVerification::L10N::en_us;

use strict;
use warnings;

use base 'LicenseVerification::L10N';
use vars qw( %Lexicon );

%Lexicon = (
);

1;
__END__
