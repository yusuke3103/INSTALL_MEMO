tinyMCE.addI18n(tinymce.settings.language, {
    mt_fullscreen: trans('Fullscreen')
});
