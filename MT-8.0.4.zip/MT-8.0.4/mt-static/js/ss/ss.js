
riot.tag2('ss', '<svg role="img" class="{opts.class}"> <title if="{opts.title}">{opts.title}</title> <use xlink:href="{opts.href}"> </use> </svg>', '', '', function(opts) {
});

