package OpenID::L10N::en_us;

use strict;
use warnings;
use utf8;
use base 'OpenID::L10N';
our %Lexicon;

1;
